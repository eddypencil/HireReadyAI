// src/features/landing/sections/FAQ.jsx
import { useState } from "react";
import { Plus, Minus } from "lucide-react";

const faqs = [
  {
    q: "How can I find jobs on HireReadyAI?",
    a: "Use the Jobs page to search by title, skill, or company. You can filter by job type, location, and salary range.",
  },
  {
    q: "Is my resume and profile data kept private?",
    a: "Yes. Your profile is only shared with employers when you explicitly apply. We never sell your data or surface your profile to recruiters without your consent.",
  },
  {
    q: "How do I track my applications?",
    a: "The My Applications dashboard gives you a real-time pipeline view — from Applied through Screening, Interview, Assessment, and Final Stage. Each card updates automatically when a recruiter takes action.",
  },
  {
    q: "Can I prepare for interviews inside the platform?",
    a: "Yes. HireReadyAI includes an AI Interview Coach that simulates common and role-specific questions, scores your responses, and gives actionable feedback on clarity, structure, and confidence.",
  },
  {
    q: "What types of roles and industries does HireReadyAI cover?",
    a: "We cover tech, design, product, marketing, finance, and operations roles across startups, scale-ups, and enterprise companies. New listings are added daily, and you can set alerts for any keyword or company.",
  },
  {
    q: "How do I upload or update my profile picture?",
    a: "Go to your Profile page, click on your avatar, and select a new image from your device. Supported formats are JPG and PNG. Your picture is visible to employers when they review your application.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState(1); // open second item by default (mirrors screenshot)

  return (
    <section className="py-20 px-4 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Left — decorative illustration column */}
          <div className="hidden md:flex flex-col items-center justify-center h-full">
            <div className="relative w-full max-w-sm">
              {/* Mock phone shell */}
              <div className="mx-auto w-52 rounded-[2.5rem] border-4 border-foreground/10 bg-card shadow-2xl overflow-hidden">
                {/* Status bar */}
                <div className="bg-surface-muted px-4 pt-3 pb-1 flex items-center justify-between">
                  <span className="text-[9px] font-bold text-foreground">
                    9:41
                  </span>
                  <div className="w-16 h-4 bg-foreground/10 rounded-full" />
                </div>
                {/* App header */}
                <div className="bg-surface-muted px-4 pb-3">
                  <p className="text-[9px] text-muted-foreground">
                    Welcome back!
                  </p>
                  <p className="text-xs font-bold text-foreground">
                    My Applications
                  </p>
                </div>
                {/* Pipeline cards */}
                <div className="bg-card px-3 py-2 space-y-2">
                  {[
                    {
                      role: "Product Designer",
                      company: "Google",
                      stage: "Interview",
                      color: "bg-stage-interview",
                    },
                    {
                      role: "UX Researcher",
                      company: "Stripe",
                      stage: "Screening",
                      color: "bg-stage-screening",
                    },
                    {
                      role: "Design Lead",
                      company: "Figma",
                      stage: "Applied",
                      color: "bg-stage-applied",
                    },
                  ].map(({ role, company, stage, color }) => (
                    <div
                      key={role}
                      className="rounded-xl border border-border bg-surface-muted p-2"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-[9px] font-semibold text-foreground">
                          {role}
                        </p>
                        <span
                          className={`text-[7px] font-bold text-white px-1.5 py-0.5 rounded-full ${color}`}
                        >
                          {stage}
                        </span>
                      </div>
                      <p className="text-[8px] text-muted-foreground">
                        {company}
                      </p>
                    </div>
                  ))}
                </div>
                {/* Bottom nav stub */}
                <div className="bg-card border-t border-border px-4 py-2 flex justify-around">
                  {["Home", "Jobs", "Track", "Profile"].map((n) => (
                    <div key={n} className="flex flex-col items-center gap-0.5">
                      <div className="w-4 h-3 bg-border rounded" />
                      <span className="text-[7px] text-muted-foreground">
                        {n}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Floating status badge */}
              <div className="absolute -right-4 top-16 bg-card border border-border rounded-xl px-3 py-2 shadow-lg">
                <p className="text-[9px] font-semibold text-foreground">
                  Interview Request
                </p>
                <p className="text-[8px] text-muted-foreground">
                  Google · 2 min ago
                </p>
              </div>
            </div>
          </div>

          {/* Right — FAQ accordion */}
          <div>
            <span className="inline-block text-[10px] font-extrabold tracking-[0.2em] text-primary bg-primary/10 px-3 py-1 rounded-full border border-primary/10 uppercase">
              FAQ
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground text-sm md:text-base mb-8 max-w-sm">
              Have questions about how HireReadyAI works? Here are the ones we
              hear most.
            </p>

            <div className="space-y-2">
              {faqs.map((faq, i) => {
                const isOpen = open === i;
                return (
                  <div
                    key={i}
                    className={`rounded-xl border transition-colors cursor-pointer
                      ${
                        isOpen
                          ? "border-primary/30 dark:border-accent/30 bg-secondary dark:bg-surface-muted"
                          : "border-border bg-card hover:bg-surface-hover"
                      }`}
                    onClick={() => setOpen(isOpen ? null : i)}
                  >
                    <div className="flex items-center justify-between px-5 py-4 gap-4">
                      <span
                        className={`text-sm font-semibold leading-snug ${isOpen ? "text-primary dark:text-accent" : "text-foreground"}`}
                      >
                        {faq.q}
                      </span>
                      <div
                        className={`shrink-0 w-7 h-7 rounded-full flex items-center justify-center border transition-colors
                        ${
                          isOpen
                            ? "border-primary/30 dark:border-accent/30 bg-primary/10 dark:bg-accent/10"
                            : "border-border bg-surface-muted"
                        }`}
                      >
                        {isOpen ? (
                          <Minus
                            size={13}
                            className="text-primary dark:text-accent"
                          />
                        ) : (
                          <Plus size={13} className="text-muted-foreground" />
                        )}
                      </div>
                    </div>
                    {isOpen && (
                      <div className="px-5 pb-4">
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {faq.a}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
